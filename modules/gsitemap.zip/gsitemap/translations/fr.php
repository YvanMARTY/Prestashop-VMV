<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{gsitemap}prestashop>gsitemap_3aaaafde6f9b2701f9e6eb9292e95521'] = 'Google Sitemaps';
$_MODULE['<{gsitemap}prestashop>gsitemap_935a6bc13704a117d22333c3155b5dae'] = 'Génère votre fichier sitemap pour Google';
$_MODULE['<{gsitemap}prestashop>gsitemap_b52bf50c73995780892b9945ddc98708'] = 'Une erreur est survenue : Impossible d\'écrire à la racine de votre site web. Veuillez ajuster les permissions afin que PrestaShop puisse enregistrer un fichier à la racine de votre site web.';
$_MODULE['<{gsitemap}prestashop>configuration_67ddb0d12fa1963b202d4ac310547709'] = 'Vos fichiers Sitemaps ont été créés avec succès. N\'oubliez pas de configurer l\'URL';
$_MODULE['<{gsitemap}prestashop>configuration_9d934413d2737c2a15f58de573657ce3'] = 'dans votre interface Google Webmaster.';
$_MODULE['<{gsitemap}prestashop>configuration_1c95b77d135b55c84429588c11697ea4'] = 'Vos fichiers sitemap';
$_MODULE['<{gsitemap}prestashop>configuration_aa17b80751f4ae53ab8e3ed2fe99e94d'] = 'Vos sitemaps ont déjà été créées.';
$_MODULE['<{gsitemap}prestashop>configuration_a0bfb8e59e6c13fc8d990781f77694fe'] = 'Continuer';
$_MODULE['<{gsitemap}prestashop>configuration_9ab08b9ceeef857df07ad10e1de9301e'] = 'Veuillez configurer l\'URL de sitemap suivante dans votre interface Google Webmaster :';
$_MODULE['<{gsitemap}prestashop>configuration_aef717e48ecd01989c92849d44bff9b6'] = 'Cette URL correspond au fichier sitemap maître et fait référence aux fichiers suivants :';
$_MODULE['<{gsitemap}prestashop>configuration_0dbf904a2b27f036cf06741aad221ecc'] = 'Votre dernière mise à jour a été effectuée le :';
$_MODULE['<{gsitemap}prestashop>configuration_6d37779958434303f8397436a1484ed8'] = 'Pour une meilleure utilisation du module, veuillez vous assurer que vous avez';
$_MODULE['<{gsitemap}prestashop>configuration_6a3282611e5ffb8539ce434133073f15'] = 'une valeur memory_limit minimale de 128 Mo.';
$_MODULE['<{gsitemap}prestashop>configuration_f891951357d4892887f0e416c54f972d'] = 'une valeur max_execution_time minimale de 30 secondes.';
$_MODULE['<{gsitemap}prestashop>configuration_8156303464de0fba7cb8306cc768e998'] = 'Vous pouvez modifier ces paramètres dans votre fichier "php.ini". Pour plus de détails, veuillez contacter votre hébergeur.';
$_MODULE['<{gsitemap}prestashop>configuration_0b9b4b91e0a8f59e264202a23d9c57a6'] = 'Configurer votre sitemap';
$_MODULE['<{gsitemap}prestashop>configuration_fe242b3dd3f455778072dc7042637a5e'] = 'Plusieurs fichiers sitemap seront générés en fonction de la configuration de votre serveur et du nombre de produits activés dans votre catalogue.';
$_MODULE['<{gsitemap}prestashop>configuration_7f751d19f85d49a411d5691f5bb0b5f2'] = 'À quelle fréquence mettez vous à jour votre boutique?';
$_MODULE['<{gsitemap}prestashop>configuration_f9f90eeaf400d228facde6bc48da5cfb'] = 'en permanence';
$_MODULE['<{gsitemap}prestashop>configuration_745fd0ea7f576f350a0eed4b8c48a8e2'] = 'toutes les heures';
$_MODULE['<{gsitemap}prestashop>configuration_bea79186fd7af2da67e59b4b15df5a26'] = 'tous les jours';
$_MODULE['<{gsitemap}prestashop>configuration_4a11fc05ed694c195f0703605b64da90'] = 'toutes les semaines';
$_MODULE['<{gsitemap}prestashop>configuration_708638881f3bac9d9c8c742c79502811'] = 'tous les mois';
$_MODULE['<{gsitemap}prestashop>configuration_1bf712896e6077fa0b708e911d8ee0b3'] = 'tous les ans';
$_MODULE['<{gsitemap}prestashop>configuration_c7561db7a418dd39b2201dfe110ab4a4'] = 'jamais';
$_MODULE['<{gsitemap}prestashop>configuration_e51d91c7bfa9fc658b11afca4d84653c'] = 'Cochez cette case si vous souhaitez vérifier la présence des fichiers d\'images sur le serveur';
$_MODULE['<{gsitemap}prestashop>configuration_05ff8159ccaef6f0f8391c61a6d0e631'] = 'Tout cocher';
$_MODULE['<{gsitemap}prestashop>configuration_0dfcf5f2f5b9ab7c909f9bdca2b53b56'] = 'Indiquez les pages que vous voulez exclure de votre sitemap :';
$_MODULE['<{gsitemap}prestashop>configuration_2ec111ec9826a83509c02bf5e6b797f1'] = 'Créer votre sitemap';
$_MODULE['<{gsitemap}prestashop>configuration_ca99f8a0d484faef3a057fe7a5da3141'] = 'Cela peut prendre plusieurs minutes';
$_MODULE['<{gsitemap}prestashop>configuration_162b34489ed8df561be1720f04fe6d42'] = 'Vous pouvez générer votre sitemap de deux manières :';
$_MODULE['<{gsitemap}prestashop>configuration_6caa369fd774beef106abbc5cc1e3368'] = 'Manuellement :';
$_MODULE['<{gsitemap}prestashop>configuration_4ed0b6a0097c3d38c43d756fe2653962'] = 'en utilisant le formulaire ci-dessus (aussi souvent que nécessaire)';
$_MODULE['<{gsitemap}prestashop>configuration_3d263eb0233f14872193733387840c80'] = '-ou-';
$_MODULE['<{gsitemap}prestashop>configuration_957d27165d1dc5947fb00e57967ffcce'] = 'Automatiquement :';
$_MODULE['<{gsitemap}prestashop>configuration_024d2d2f6d7fd575701fd1b30cc5c0c2'] = 'Demandez à votre hébergeur de mettre en place une \"tâche Cron\" pour charger l\'URL suivante à la fréquence de votre choix :';
$_MODULE['<{gsitemap}prestashop>configuration_8076be06e575e50c7f9585271c8842ad'] = 'Cela générera automatiquement vos fichiers sitemap XML.';
$_MODULE['<{gsitemap}prestashop>configuration_98a9d595be84a0687c4b26887977e0c3'] = 'Tout décocher';


return $_MODULE;
