<?php
 class parcours{
     public $id;
     public $nom;
     public $time;
     public $active;
     public $points;
     public $prix;

     function __construct(/*$data*/){
      /* $this->id = $data['prc_id'];
       $this->nom = $data['prc_nom'];
       $this->time = $data['prc_prix'];
       $this->active = $data['prc_tmp'];*/
    }
 }

 
 

?>