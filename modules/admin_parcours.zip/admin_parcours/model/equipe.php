<?php
 class equipe{
     public $id;
     public $nom;
     public $score;
     public $equipes;
 }

 function __construct(/*$data*/){
   /* $this->id = $data['prc_id'];
    $this->nom = $data['prc_nom'];
    $this->time = $data['prc_prix'];
    $this->active = $data['prc_tmp'];*/
 }
 

?>